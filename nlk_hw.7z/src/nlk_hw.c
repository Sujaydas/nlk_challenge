#include <limits.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

#include "nlk_hw.h"
#include "nlk_peripherals.h"


/* static variables */
volatile static uint8_t tx_buffer[10] = {};
volatile static uint8_t rx_buffer[3] = {};

volatile static NLK_STATE eNlkState = NLK_AWAKE;
volatile static long unsigned int nTickCount = 0;
volatile static int16_t nTempvalue_celsius = 0;
volatile static int16_t nPreviousReadTempValue_celsius = 0;
volatile static int16_t nTempvalue_kelvin = 0;
volatile static bool flag_2s = true;
FILE *fptr;

/* static methods not exposed to user */
nlk_err_code configureTempSensor(void);

void createConfigurePacket(void);
void createRDIDPacket(void);
void createSleepPacket(void);
void createAwakePacket(void);

nlk_err_code configureTempSensor(void);
nlk_err_code sendRDIDCmd(void);
nlk_err_code sendRDTempCmd(void);
nlk_err_code sendSleepCmd(void);
nlk_err_code sendAwakeCmd(void);

nlk_err_code nlk_spi_transact(size_t len);





void createConfigurePacket(void){
	
	memset((uint8_t *)&tx_buffer[0], 0, MAX_TX_BUF_LEN);

	tx_buffer[0] = NLK_SPI_TEMP_CONFIG;
	tx_buffer[1] = NLK_SPI_TEMP_DUMMY;

	tx_buffer[2] = NLK_SPI_CONFIG_MARKER;
	tx_buffer[3] = NLK_SPI_CONFIG_RESERVED;
	tx_buffer[4] = NLK_SPI_CONFIG_MEASUREMNT_MODE;
	tx_buffer[5] = NLK_SPI_CONFIG_CALIBRATE;
	tx_buffer[6] = NLK_SPI_CONFIG_RESERVED;
	tx_buffer[7] = NLK_SPI_CONFIG_RESERVED;
	tx_buffer[8] = NLK_SPI_CONFIG_RESERVED;
	tx_buffer[9] = NLK_SPI_CONFIG_RESERVED;
}

void createRDIDPacket(void){
	memset((uint8_t *)&tx_buffer[0], 0, MAX_TX_BUF_LEN);
	tx_buffer[0] = NLK_SPI_TEMP_RDID;
}

void createRDTempPacket(void){
	memset((uint8_t *)&tx_buffer[0], 0, MAX_TX_BUF_LEN);
	tx_buffer[0] = NLK_SPI_TEMP_RDTEMP;
	tx_buffer[1] = NLK_SPI_TEMP_DUMMY;

}

void createSleepPacket(void){
	memset((uint8_t *)&tx_buffer[0], 0, MAX_TX_BUF_LEN);
	tx_buffer[0] = NLK_SPI_TEMP_SLEEP;
}

void createAwakePacket(void){
	memset((uint8_t *)&tx_buffer[0], 0, MAX_TX_BUF_LEN);
	tx_buffer[0] = NLK_SPI_TEMP_AWAKE;
}

/* 
    @description: This function sends command packet to the sensor and gets the data back
    @param: len: length of tx and rx buffer sent in this transaction
    @return: nlk_err_code: NLK_ERR_CODE_SUCCESS on succesful execution of function
                           if there is any timeout issues or other bus issues return the error code back to user
*/
nlk_err_code nlk_spi_transact(size_t len){
	nlk_err_code error_code = NLK_ERR_CODE_SUCCESS;

	/* Bring the SPI CS line low to start the transaction */	
	error_code = nlk_peripherals_set_gpio(SPI_CS_GPIO, false);
	if(NLK_ERR_CODE_SUCCESS != error_code){
		return error_code;
	}

	/* Use the model functionality to get the data back from the temperature sensor */
	error_code = nlk_peripherals_spi_transact((uint8_t *)&tx_buffer[0], (uint8_t *)&rx_buffer[0], len);
	if(NLK_ERR_CODE_SUCCESS != error_code){
		return error_code;
	}

	/* Bring the SPI CS line high */
	error_code = nlk_peripherals_set_gpio(SPI_CS_GPIO, true);
	if(NLK_ERR_CODE_SUCCESS != error_code){
		return error_code;
	}

	return error_code;
}

/* 
    @description: This function creates the CONFIG packet and sends to the sensor
    @param: None
    @return: nlk_err_code: NLK_ERR_CODE_SUCCESS on succesful execution of function
                           if there is any timeout issues or other bus issues return the error code back to user
*/
nlk_err_code sendConfigureCmd(void){

	createConfigurePacket();
	
	return nlk_spi_transact(CONFIG_PACKET_LENGTH);	
}

/* 
    @description: This function creates the RDID packet and sends to the sensor and gets the ID data back
    @param: None
    @return: nlk_err_code: NLK_ERR_CODE_SUCCESS on succesful execution of function
                           if there is any timeout issues or other bus issues return the error code back to user
*/
nlk_err_code sendRDIDCmd(void){
	
	createRDIDPacket();
	
	return nlk_spi_transact(RDID_PACKET_LENGTH);
}


/* 
    @description: This function creates the RDTEMP packet and sends to the sensor and gets the temperature 2 bytes data back
    @param: None
    @return: nlk_err_code: NLK_ERR_CODE_SUCCESS on succesful execution of function
                           if there is any timeout issues or other bus issues return the error code back to user
*/
nlk_err_code sendRDTempCmd(void){
	
	createRDTempPacket();
	
	return nlk_spi_transact(RDTEMP_PACKET_LENGTH);
}


/* 
    @description: This function creates the SLEEP packet and sends to the sensor
    @param: None
    @return: nlk_err_code: NLK_ERR_CODE_SUCCESS on succesful execution of function
                           if there is any timeout issues or other bus issues return the error code back to user
*/
nlk_err_code sendSleepCmd(void){
	
	createSleepPacket();
	
	return nlk_spi_transact(SLEEP_PACKET_LENGTH);
}

/* 
    @description: This function creates the AWAKE packet and sends to the sensor
    @param: None
    @return: nlk_err_code: NLK_ERR_CODE_SUCCESS on succesful execution of function
                           if there is any timeout issues or other bus issues return the error code back to user
*/
nlk_err_code sendAwakeCmd(void){
	
	createAwakePacket();

	return nlk_spi_transact(AWAKE_PACKET_LENGTH);
}


/* 
    @description: This function toggles the GPIO4 depending the temperature data, it takes care of the 1 degree celsius of hystersis
    @param: None
    @return: nlk_err_code: NLK_ERR_CODE_SUCCESS on succesful execution of function
			   NLK_ERR_CODE_UNKNOWN If the opening CSV file causes issue
                           if there is any timeout issues or other bus issues return the error code back to user
*/
nlk_err_code nlk_toggle_GPIO(){
	nlk_err_code error_code = NLK_ERR_CODE_SUCCESS;

	bool value = false; /* bool value stored in the csv file */

	FILE *fptr;
	/* Open the file for updating the feilds */
	fptr = fopen(GPIO4_TEMPSNSR_DATA_FILE, "a");
	if(!fptr){
		return NLK_ERR_CODE_UNKNOWN;
	}

	/* If the temperature is above 37 degrees Celsius, then pin 4 should be set to high, else it should be low. */
	if(nTempvalue_celsius < 37){

		error_code = nlk_peripherals_set_gpio(TEMP_TOGGLE_GPIO, false);
		if(NLK_ERR_CODE_SUCCESS != error_code){
			return error_code;
		}
	        value = false;

	}else if(nTempvalue_celsius > 37){
		
		error_code = nlk_peripherals_set_gpio(TEMP_TOGGLE_GPIO, true);
		if(NLK_ERR_CODE_SUCCESS != error_code){
			return error_code;
		}
		value = true;
	}

	/* Save the Temperature data and gpio4 toggling data to the file */
	fprintf(fptr, "\n%ld,%d,%d", nTickCount, value, nTempvalue_celsius);
	fclose(fptr);
	
	return error_code;
}


nlk_err_code readTempData(){
	nlk_err_code error_code = NLK_ERR_CODE_SUCCESS;

	/* Get the Current Tick count and wait for two more ticks to perform the read operations */	
	static uint32_t nCurrentTick = 0u;
	
	switch(eNlkState){

		/* Part is default in AWAKE mode. */
		case NLK_AWAKE:
		{	
			if(nTickCount == (nCurrentTick + WAIT_AFTER_AWAKE)){  //wait for 2 tick seconds

				/* If the 2 ticks are over perform read operations */

				/* send RDID cmd and get response */
				error_code = sendRDIDCmd();
				if(NLK_ERR_CODE_SUCCESS != error_code){
					return error_code;
				}

				printf("RDID command done: MFRID:%#02x, DEVID:%#02x\n", rx_buffer[1], rx_buffer[2]);

				/* send RDTemp cmd and get response */
				error_code = sendRDTempCmd();
				if(NLK_ERR_CODE_SUCCESS != error_code){
					return error_code;
				}

				/* Convert the kelvin temperature data to celsius, I'm generating the random values of temperature between -20C to +50C, kelvin range is from 250 - 350 */
				nTempvalue_kelvin = ((rx_buffer[2] << 8) | (rx_buffer[3])); 
				nTempvalue_celsius = nTempvalue_kelvin - 273;

				printf("RDTEMP command done: Temp in kelvin:%d, Temp in Celsius:%d\n", nTempvalue_kelvin, nTempvalue_celsius);

				/* GPIO toggle depending on the temperature value */
				error_code = nlk_toggle_GPIO();
				if(NLK_ERR_CODE_SUCCESS != error_code){
					return error_code;
				}

				/* This is for shutdown test for Module 3 */
#if MODEL_3
				if(nTempvalue_celsius > MAX_THRESHOLD_TEMP){
					return NLK_ERR_CODE_UNKNOWN;
				}
#endif
				/* send sleep cmd and get response */
				error_code = sendSleepCmd();
				if(NLK_ERR_CODE_SUCCESS != error_code){
					return error_code;
				}
				
				printf("Sleeping........\n");

				/* Mode changed to SLEEP mode */
				eNlkState = NLK_SLEEP;

				/* Update the current count which will be used to wait another 3 seconds for getting the data */
				nCurrentTick = nTickCount;
				flag_2s = true;

			}
			else
			{
				/* If the Ticks are not yet happened, first time get the Current Tick count and wait for two more ticks to perform the read operations */
				if(flag_2s){
					flag_2s = false;
					nCurrentTick = nTickCount; //tick value when the control entered first time					
				}
			}

		}
		break;

		case NLK_SLEEP:
		{
			if(nTickCount == (nCurrentTick + 3u)){  //wait for 3 seconds after the previous read of temperature
				
				/* send Awake cmd and get response after waiting 3 seconds */
				error_code = sendRDIDCmd();
				if(NLK_ERR_CODE_SUCCESS != error_code){
					return error_code;
				}

				printf("Woke up waiting 2 seconds for Temperature sensor to come up..\n");
				/* Mode changed to AWAKE mode */
				eNlkState = NLK_AWAKE;

				/* Update the current count which will be used to wait another 2 seconds for getting the data */
				nCurrentTick = nTickCount;
			}		

		}
		break;

		default:
		{
			//no op

		}
		break;
	}

	return error_code;

}



// Called once on boot.
nlk_err_code nlk_hw_init(void){
	nlk_err_code error_code = NLK_ERR_CODE_SUCCESS;

	/* Get the Current Tick count and wait for two more ticks to finish the configuration procedure */
	uint32_t nWait2TickSeconds = nTickCount;
	
	/* Open the file for updating the feilds */
	fptr = fopen(GPIO4_TEMPSNSR_DATA_FILE, "a");
	if(!fptr){
		return NLK_ERR_CODE_UNKNOWN;
	}

	/* Final csv file will have Ticks, gpio4_value, temperature in celsius data which will be used for plotting */
	fprintf(fptr,"Ticks,GPIO_value,Temperature_Celsius");
	fclose(fptr);

	/*
            Configure the temperature sensor 		
         */
	error_code = sendConfigureCmd();
	if(NLK_ERR_CODE_SUCCESS != error_code){
		return error_code;
	}

	/* Wait for 2 seconds after config */	
	while(nTickCount <= (nWait2TickSeconds + WAIT_AFTER_CONFIG));
	
	return error_code;
}



// Called once on shutdown.
nlk_err_code nlk_hw_uninit(void){
	/* send sleep cmd and get response */
	return sendSleepCmd();
}



// Called periodically.
nlk_err_code nlk_hw_tick(void){
	nlk_err_code error_code = NLK_ERR_CODE_SUCCESS;

	/*
		No need to handle this since the nTickCount is unsigned and after UINT_MAX it changes to 0
		if(nTickCount == UINT_MAX){
			nTickCount = 0u;
		}else{
			nTickCount++;
		}
	*/

	/* Get the time value */
	time_t clk = time(NULL);

	/* Update the tick counter value which indicates the tick() is called. */
	nTickCount++;

	printf("TickCount: (%ld), time:%s \n", nTickCount, ctime(&clk));

	/* No error scenarios for this function since it just updates the tick counter */
	return error_code;

}






















