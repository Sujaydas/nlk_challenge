import random
from itertools import count
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

plt.style.use('fivethirtyeight')

x_vals = []
y_vals = []


index = count()

def animate(i):
	data = pd.read_csv('gpio4_temperature_data.csv')

	x = data['Ticks']
	y1 = data['GPIO_value']
	y2 = data['Temperature_Celsius']

	plt.cla()
	plt.plot(x, y1, label='GPIO4_status')
	plt.plot(x, y2, label= 'Temperature')

	plt.legend(loc='upper left')
	plt.tight_layout()
	plt.xlabel("# of Ticks")
	plt.ylabel("Temepature and GPIO toggle")


ani = FuncAnimation(plt.gcf(), animate, interval=5000)

plt.show()



