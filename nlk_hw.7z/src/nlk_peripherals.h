/*
 * nlk_peripherals.h
 *
 * Definition of the interface to imaginary peripherals.
 *
 */

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "nlk_errors.h"

#define NLK_SPI_TEMP_DUMMY  (uint8_t) 0x00
#define NLK_SPI_TEMP_RDID   (uint8_t) 0x9F
#define NLK_SPI_TEMP_SLEEP  (uint8_t) 0xB9
#define NLK_SPI_TEMP_AWAKE  (uint8_t) 0xAB
#define NLK_SPI_TEMP_RDTEMP (uint8_t) 0x03
#define NLK_SPI_TEMP_CONFIG (uint8_t) 0x06
#define NLK_SPI_TEMP_MRF_ID (uint8_t) 0x36
#define NLK_SPI_TEMP_DEV_ID (uint8_t) 0xC9


#define NLK_SPI_CONFIG_MARKER           (uint8_t) 0xEE
#define NLK_SPI_CONFIG_MEASUREMNT_MODE  (uint8_t) 0x03
#define NLK_SPI_CONFIG_CALIBRATE        (uint8_t) 0x01
#define NLK_SPI_CONFIG_RESERVED         (uint8_t) 0x00


#define RAND_LOW_RANGE_TEMP_KELVIN       (250u)
#define RAND_HIGH_RANGE_TEMP_KELVIN      (350u)

#define MODEL_1      (1u)  // random temperature data tests
#define MODEL_2      (0u)  // threshold temperature value tests
#define MODEL_3      (0u)  // shutdown test

#ifdef __cplusplus
extern "C" {
#endif

// Sets the output of a GPIO pin to either high (true) or low (false).
// Can return ERR_CODE_INVALID_ARG, ERR_CODE_UNKNOWN.
nlk_err_code nlk_peripherals_set_gpio(uint8_t pin, bool value);

// Perform SPI transaction.
//
// Args:
//  - tx_buf: buffer containing outgoing (MOSI) data
//  - rx_buf: buffer containing incoming (MISO) data
//  - len: number of bytes processed by the clock line
//         (i.e. number of bytes that tx/rx will transmit/receive simultaneously)
//
// Can return ERR_CODE_TIMEOUT, ERR_CODE_INVALID_ARG, ERR_CODE_UNKNOWN.
nlk_err_code nlk_peripherals_spi_transact(uint8_t* tx_buf, uint8_t* rx_buf, size_t len);

#ifdef __cplusplus
}
#endif
