#include <stdio.h>
#include "nlk_hw.h"
#include "nlk_peripherals.h"
#include "nlk_errors.h"

#include "timer.h"


/* timer handler which is returned when the timer is created and will be used to start the timer, stop the timer */
size_t timer_tick;

/* This is timer handler function which will be called when the timer expires, timer is configred to trigger event every 1000ms */
void time_handler_tick(size_t timer_id, void * user_data)
{
	/* since this is the simulated timer trigger, manually call the tick() function. */
	nlk_err_code error_code = nlk_hw_tick();	
	if(NLK_ERR_CODE_SUCCESS != error_code){

		/* If the tick function fails stop all the timers and join the thread */
		printf("nlk_hw_tick failed: %s:%d", __FILE__, __LINE__);
		stop_timer(timer_tick);
		finalize();
	}
}


int main(){

	/* Create timer threads to handle the tick() call every 1second in parallel with reading temperature data  */

	nlk_err_code error_code = initialize();
	if(NLK_ERR_CODE_SUCCESS != error_code){
		return 0;
	}

	/* Start the timer which triggers the tick() every 1 second, which will be used for waiting for different commands */
	timer_tick = start_timer(1000, time_handler_tick, TIMER_PERIODIC, NULL);

	/* This function will be called once on boot. This method sends the config command and wait for 2 seconds, since 
           Config BYte#3 is set as 1, also creates the csv file which holds the GPIO toggle data and temperature values read. */
	error_code = nlk_hw_init();
	if(NLK_ERR_CODE_SUCCESS != error_code){
		return 0;
	}
	

	/* 
	   This is the testing loop which continuosly reads the rdid, rdtemp and puts the part in the sleep mode. 
           For every 5 seconds the temperature reading are taken, since we have to wait 2 seconds after awake to get the temperature reading valid, 
	   for every 3 seconds the tick wakes up the temp sensor and wait for 2 seconds and reads the rdid, rdtemp and goes back to sleep again.
           If In any of these operations error occurs the loop exists and performs the unint
        */
	while(NLK_ERR_CODE_SUCCESS == error_code){
		error_code = readTempData();
	}

	error_code = nlk_hw_uninit();
	if(NLK_ERR_CODE_SUCCESS != error_code){
		return 0;
	}

	printf("Sleeping........\n");

	stop_timer(timer_tick);
	finalize();

}
