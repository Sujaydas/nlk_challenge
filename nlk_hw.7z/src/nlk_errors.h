/*
 * nlk_errors.h
 *
 * Error code definitions.
 *
 */

#include "stdint.h"

typedef int nlk_err_code;

#define NLK_ERR_CODE_SUCCESS     (uint32_t) 0
#define NLK_ERR_CODE_UNKNOWN     (uint32_t) 1
#define NLK_ERR_CODE_TIMEOUT     (uint32_t) 2
#define NLK_ERR_CODE_INVALID_ARG (uint32_t) 3