/*timer.c*/

#include <stdint.h>
#include <string.h>
#include <sys/timerfd.h>
#include <pthread.h>
#include <poll.h>
#include <stdio.h>
#include <unistd.h>
#include "timer.h"

#define MAX_TIMER_COUNT 1000

struct timer_node
{
    int                 fd;
    time_handler        callback;
    void *              user_data;
    unsigned int        interval;
    t_timer             type;
    struct timer_node * next;
};

static void * _timer_thread(void * data);
static pthread_t g_thread_id;
static struct timer_node *g_head = NULL;


/* 
    @description: This function creates the timer thread that monitors the timers whether timer is expired
    @param: None
    @return: NLK_ERR_CODE_SUCCESS - if pthread_create is success
             NLK_ERR_CODE_UNKNOWN - if pthrea_create fails
	
*/
nlk_err_code initialize()
{
    if(pthread_create(&g_thread_id, NULL, _timer_thread, NULL))
    {
        /*Thread creation failed*/
        return NLK_ERR_CODE_UNKNOWN;
    }

    return NLK_ERR_CODE_SUCCESS;
}



/* 
    @description: Creates a timer and return the id of the timer.It first allocates memory (new_node) for the timer and stores related 
                  information such as callback function, interval, type (periodic or single shot) of the timer in the new_node structure.
                  Then it creates the timer using timerfd_create() function and stores the returned fd (file descriptor) in new_node. Time out interval 
                  is set in new_value.it_value.tv_sec variable and in case of periodic timer the interval is set in 
                  new_value.it_interval.tv_sec variable also. Then it starts the timer using timerfd_settime() function.
                  At the end it inserts the timer structure (new_node) in the linked list.
                  
    @param:

    interval:  Timeout interval in milli seconds. If interval is 10, the timer will expire (call handler callback) after 10 milli seconds.
               And in case of periodic timer, it will keep calling the handler in every 10 milli seconds.
    handler:   The call back function pointer. Library will call this function in every timer expiry.
    type:      Whether the timer is periodic or single shot. For periodic, the value is TIMER_PERIODIC and for single shot the value is TIMER_SINGLE_SHOT.
    user_data: User can set any data as void pointer. Library will call the callback handler with this data.

    @return: The returned timer id would be used to stop the timer.
	
*/
size_t start_timer(unsigned int interval, time_handler handler, t_timer type, void * user_data)
{
    struct timer_node * new_node = NULL;
    struct itimerspec new_value;

    new_node = (struct timer_node *)malloc(sizeof(struct timer_node));

    if(new_node == NULL) return 0;

    new_node->callback  = handler;
    new_node->user_data = user_data;
    new_node->interval  = interval;
    new_node->type      = type;

    /* The timerfd_create() creates a timer and returns a handler of the timer, fd (file descriptor). 
       This fd can be used to start or monitor the timer later. 
    */
    new_node->fd = timerfd_create(CLOCK_REALTIME, 0);

    if (new_node->fd == -1)
    {
        free(new_node);
        return 0;
    }

    new_value.it_value.tv_sec = interval / 1000;
    new_value.it_value.tv_nsec = (interval % 1000)* 1000000;

    if (type == TIMER_PERIODIC)
    {
      new_value.it_interval.tv_sec= interval / 1000;
      new_value.it_interval.tv_nsec = (interval %1000) * 1000000;
    }
    else
    {
      new_value.it_interval.tv_sec= 0;
      new_value.it_interval.tv_nsec = 0;
    }

    /* 
        The timerfd_settime() starts the timer. We can also specify whether the timer is periodic or single shot.
    */
    timerfd_settime(new_node->fd, 0, &new_value, NULL);

    /*Inserting the timer node into the list*/
    new_node->next = g_head;
    g_head = new_node;

    return (size_t)new_node;
}


/* 
    @description: Stops a particular timer specified by the input timer id.
		It stops the timer by calling close() system call with the file descriptor (fd) of the timer.
                Then it removed the timer data structure from the linked list.
                  
    @param:   Timer id is returned by the start_timer() function in time of creating the timer. 

    @return: None
	
*/

void stop_timer(size_t timer_id)
{
    struct timer_node * tmp = NULL;
    struct timer_node * node = (struct timer_node *)timer_id;

    if (node == NULL) return;

    if(node == g_head)
    {
        g_head = g_head->next;
    } else {

      tmp = g_head;

      while(tmp && tmp->next != node) tmp = tmp->next;

      if(tmp)
      {
          /*tmp->next can not be NULL here*/
          tmp->next = tmp->next->next;
          close(node->fd);
          free(node);
      }
    }
}


/* 
    @description: It should be called when the timer library will no longer be required. It stops (and deletes) all running timers.  
                   It first stops all running timers and then stops the thread.
    @param:  None

    @return: None
	
*/

void finalize()
{
    while(g_head) stop_timer((size_t)g_head);

    pthread_cancel(g_thread_id);
    pthread_join(g_thread_id, NULL);
}


struct timer_node * _get_timer_from_fd(int fd)
{
    struct timer_node * tmp = g_head;

    while(tmp)
    {
        if(tmp->fd == fd) return tmp;

        tmp = tmp->next;
    }
    return NULL;
}


/* 
    @description: It continuously checks if any timer file descriptor (fd) is set using poll() system call. If any timer file descriptor
                 is set and readable using read() system call, then it calls the callback function of the timer with timer id and user_data. 

    @param:  data

    @return: None
	
*/

void * _timer_thread(void * data)
{
 
    struct pollfd ufds[MAX_TIMER_COUNT] = {{0}};
    int iMaxCount = 0;
    struct timer_node * tmp = NULL;
    int read_fds = 0, i, s;
    uint64_t exp;

    while(1)
    {
        pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
        pthread_testcancel();
        pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);

        iMaxCount = 0;
        tmp = g_head;

        memset(ufds, 0, sizeof(struct pollfd)*MAX_TIMER_COUNT);
        while(tmp)
        {
            ufds[iMaxCount].fd = tmp->fd;
            ufds[iMaxCount].events = POLLIN;
            iMaxCount++;

            tmp = tmp->next;
        }

        /* 
         If a timer expires, the corresponding file descriptors (fd) will be readable using read() system call. 
        We to have one thread in our library that continuously checks all file descriptors (fd) using poll() system call. 
        If any file descriptor is set (POLLIN), we call the expiry callback function of the corresponding timer. 
        */
        read_fds = poll(ufds, iMaxCount, 100);

        if (read_fds <= 0) continue;

        for (i = 0; i < iMaxCount; i++)
        {
            if (ufds[i].revents & POLLIN)
            {
                s = read(ufds[i].fd, &exp, sizeof(uint64_t));

                if (s != sizeof(uint64_t)) continue;

                tmp = _get_timer_from_fd(ufds[i].fd);

                if(tmp && tmp->callback) tmp->callback((size_t)tmp, tmp->user_data);
            }
        }
    }

    return NULL;

}








