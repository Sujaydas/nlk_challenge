/*
 * nlk_hw.h
 *
 * Header for Neuralink Firmware homework challenge.
 *
 * You must implement these functions.
 *
 */

#include "nlk_errors.h"

#define GPIO4_TEMPSNSR_DATA_FILE  "./gpio4_temperature_data.csv"

#define WAIT_AFTER_AWAKE    (2u)
#define WAIT_AFTER_CONFIG   (2u)

#define RDID_PACKET_LENGTH    (3u)
#define RDTEMP_PACKET_LENGTH  (4u)
#define AWAKE_PACKET_LENGTH   (1u)
#define SLEEP_PACKET_LENGTH   (1u)
#define CONFIG_PACKET_LENGTH  (10u)

#define SPI_CS_GPIO           (2u)
#define TEMP_TOGGLE_GPIO      (4u)

#define MAX_TX_BUF_LEN           (10u)
#define MAX_RX_BUF_LEN           (10u)

#define MAX_THRESHOLD_TEMP      (100u)

typedef enum nlk_state {
	NLK_AWAKE,
	NLK_SLEEP,
	NLK_INVALID
}NLK_STATE;


// Called once on boot.
/* 
    @description: This function will be called once on boot.
		  This method sends the config command and wait for 2 seconds, since 
		  Config BYte#3 is set as 1, also creates the csv file which holds the GPIO toggle data and
                  temperature values read.
    @param: None
    @return: nlk_err_code: NLK_ERR_CODE_SUCCESS on succesful execution of function
                           NLK_ERR_CODE_UNKNOWN: if file creation fails
			   nlk_err_code: if sending Config command fails
*/
nlk_err_code nlk_hw_init(void);




// Called once on shutdown.
/* 
    @description: This function will be called by the end of the program during shutdown, which sends the sleep command to the temp sensor
    @param: None
    @return: nlk_err_code
	
*/
nlk_err_code nlk_hw_uninit(void);




// Called periodically.
/* 
    @description: This function will be called by the timer every 1 second, and this method updates the 
		global nTickCount variable which will be used for timing different command operations
    @param: None
    @return: nlk_err_code
	
*/
nlk_err_code nlk_hw_tick(void);


/* 
    @description: this is the testing loop which continuosly reads the rdid, rdtemp and puts the part in the sleep mode. 
           For every 5 seconds the temperature reading are taken, since we have to wait 2 seconds after awake to get the temperature reading valid, 
	   for every 3 seconds the tick wakes up the temp sensor and wait for 2 seconds and reads the rdid, rdtemp and goes back to sleep again.
           If In any of these operations error occurs the loop exists and performs the unint
    @param: None
    @return: NLK_ERR_CODE_SUCCESS and other nlk_err_code error codes
	
*/

nlk_err_code readTempData(void);



