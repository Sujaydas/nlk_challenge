/*
 * nlk_peripherals.c
 *
 * Minimal implementation of peripherals.
 * Expand this module as required to test your code.
 *
 */

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

#include "nlk_peripherals.h"

bool gGpioPins[8] = {false};

#ifdef MODEL_2
uint16_t temperature_data_2[] = {309, 310, 311, 312, 313, 306, 307, 308, 309, 310, 311, 312, 313, 309, 310, 311, 312, 313, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 320, 360};
#endif


#ifdef MODEL_3
uint16_t temperature_data_3[] = {309, 310, 311, 312, 313, 1000, 307, 308, 309, 310, 311, 312, 313, 309, 310, 311, 312, 313, 306, 307, 1000, 309, 310, 311, 312, 313, 314, 315, 320, 360};
#endif

nlk_err_code nlk_peripherals_set_gpio(uint8_t pin, bool value) {

	if(pin > 7){
		return NLK_ERR_CODE_INVALID_ARG;
	}

	gGpioPins[pin] = value;	
	return NLK_ERR_CODE_SUCCESS;
}

/*
  Randomly generating values between low and high values

 */
uint16_t generateRandTemp(uint16_t low, uint16_t high){

	return (rand() % (high - low + 1) + low);
}



nlk_err_code nlk_peripherals_spi_transact(uint8_t* tx_buf, uint8_t* rx_buf, size_t len) {
  memset(rx_buf, 0, len);

#if MODEL_2
  static uint8_t index = 0;
#elif MODEL_3
  static uint8_t index = 0;
#endif
  
  // As we go through the tx and rx buffers, we need to ensure
  // we are not going beyond `len` and overflowing the buffer.
  // If we don't have enough room, the transaction was roughly a no-op.

  // Check if tx_buf is null
  if(!tx_buf){
     return NLK_ERR_CODE_INVALID_ARG;
  }
  // Check we have enough room for reading the ID.
  if (len < 3) {
    return NLK_ERR_CODE_SUCCESS;
  }

  // Read ID
  if (tx_buf[0] == NLK_SPI_TEMP_RDID) {

    if(!rx_buf){
      return NLK_ERR_CODE_INVALID_ARG;
    }
    else
    {
      /* If we are here means the length of the transaction is 3 and command is RDID, we have to make sure the rx has enough buffer, since its the model 
         won't be doing any checks on rx buf;
       */
      rx_buf[0] = 0;
      rx_buf[1] = NLK_SPI_TEMP_MRF_ID;
      rx_buf[2] = NLK_SPI_TEMP_DEV_ID;
      return NLK_ERR_CODE_SUCCESS;
    }
  }

  // Check we have enough room for reading a temperature.
  if (len < 4) {
    return NLK_ERR_CODE_SUCCESS;
  }

  // Read temp, return 40 C (313 K).
  if ((tx_buf[0] == NLK_SPI_TEMP_RDTEMP) && (tx_buf[1] == NLK_SPI_TEMP_DUMMY)) {
	if(!rx_buf){
            return NLK_ERR_CODE_INVALID_ARG;
        }
        else
        {
	    /* If we are here means the length of the transaction is 4 and command is RDTEMP, we have to make sure the rx has enough buffer, since its the model 
		 won't be doing any checks on rx buf;
	    */
#if MODEL_1

	    /* testing with random range of values */
	    uint16_t randTemp = generateRandTemp(250, 350);
            rx_buf[2] = ((randTemp >> 8) & 0xFF);
            rx_buf[3] = (randTemp & 0xFF);
#elif MODEL_2
	    /* Testing the boarder threshold values */
	    uint16_t randTemp = temperature_data_2[index];
            rx_buf[2] = ((randTemp >> 8) & 0xFF);
            rx_buf[3] = (randTemp & 0xFF);
	
            if(index < sizeof(temperature_data_2)){
	        index++;
	    }else{
	        index = 0u;
	    }
#elif MODEL_3
	    /* Testing the shutdown cases when high temperature is set */
	    uint16_t randTemp = temperature_data_3[index];
            rx_buf[2] = ((randTemp >> 8) & 0xFF);
            rx_buf[3] = (randTemp & 0xFF);
	
            if(index < sizeof(temperature_data_3)){
	        index++;
	    }else{
	        index = 0u;
	    }
#endif
        }

    return NLK_ERR_CODE_SUCCESS;
  }

  /* return success in case of CONFIG, SLEEP, AWAKE, since none of the checks passes */
  return NLK_ERR_CODE_SUCCESS;
}
