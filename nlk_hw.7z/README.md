# Neuralink Firmware Homework

This exercise will require you to write some firmware to talk to a
temperature sensor via SPI once a second, and based on the current value,
toggle a GPIO pin with some hysteresis. You can assume that this code is
running on a small microcontroller with minimal memory, minimal battery and
without any sort of operating system.

`nlk_hw.h` is a header file that defines the entry points to your code.
You are expected to implement each function, and these can branch out
into other modules or functions as you see necessary.
  - `nlk_hw_init()` is called once on boot
  - `nlk_hw_tick()` is called periodically at 1 Hz
  - `nlk_hw_uninit()` is called prior to shutdown where the device goes to sleep

If any of these functions encounter an error during execution, they should
return non-success error codes. You may expand `nlk_errors.h` if you wish.

`nlk_peripherals.h` defines two IO functions that you will call in order to
interface with some imaginary peripherals. We have implemented an extremely
minimal amount of functionality to model these so that you can run your code,
but you should feel free to expand them as required to test functionality.
For example, the current implementation for `nlk_peripherals_spi_transact()`
does not take chip select into account, and thus will work regardless of chip
select being used or not (which is thus badly mocked functionality).

NOTE: You should not change the function definitions in any of the header files.

After you submit your work, we will compile your code with more elaborate
versions of these functions to better mock the behavior of real peripherals
in a harsh environment with interference, dead chips, bus failures, etc.
Please do not include any non-standard headers that would require installation
of dependencies.

### Pointers for Success

You should consider this work to be production code that will get
deployed on a real medical implant. Here are some suggested pointers
for success:

  - Comments, comments, comments! Imagine you're writing this in a team.
  - Keep it clean, simple, and easy to read.
  - The microcontroller should gracefully fail when there are errors.
    We recommend checking that input data is valid and to print logs if errors are detected.
  - There should be thorough unit tests that demonstrate the functionality of your code.
    E.g. checking graceful failure, checking GPIO state is correct for given temperatures, etc.

We recommend using C or C++ and the project needs to compile on a standard
Linux machine. There should be instructions on how to compile your
code and any test targets that you create - Makefile or CMake are good choices.
While this will be compiling on x86, you should use any compile flags that
you consider useful for an embedded system that has tight flash constraints
and limited compute.

### Temperature Sensor

The temperature sensor is on an SPI bus (mode 0) and you should assume that there are
also other devices sharing the bus. Chip select for this sensor is pin 2 and you can
use `nlk_set_gpio()` and `nlk_spi_transact()` functions to communicate with it.

Command Set
============

+=========+======+========+========+============+===========+
| Command | Line | Byte 1 | Byte 2 |   Byte 3   |  Byte 4   |
+=========+======+========+========+============+===========+
| RDID    | MOSI | 0x9F   |        |            |           |
|         | MISO |        | MFR_ID | DEV_ID     |           |
+---------+------+--------+--------+------------+-----------+
| SLEEP   | MOSI | 0xB9   |        |            |           |
+---------+------+--------+--------+------------+-----------+
| AWAKE   | MOSI | 0xAB   |        |            |           |
+---------+------+--------+--------+------------+-----------+
| RDTEMP  | MOSI | 0x03   | Dummy  |            |           |
|         | MISO |        | (0x00) | TEMP[15:8] | TEMP[7:0] |
+---------+------+--------+--------+------------+-----------+

+=========+======+========+========+========================+
| Command | Line | Byte 1 | Byte 2 |        Byte 3-10       |
+=========+======+========+========+========================+
| CONFIG  | MOSI | 0x06   | Dummy  |    USER CONFIG [8B]    |
+---------+------+--------+--------+------------------------+

* RDID (0x9F): Standard JEDEC ID read where MFR_ID=0x36, DEV_ID=0xC9.
* AWAKE (0xAB): Wake device from deep power down state. Note: After sending this command, temperature reads are invalid for 2s.
* SLEEP (0xB9): Deep power down state with 14uA active power consumption at 1.8V.
* RDTEMP (0x03): Read 16b signed integer in Kelvin. A dummy byte (0x00) is required to latch the latest measured data to be read.
* CONFIG (0x06): Write 8 bytes of USER configuration on boot after waking up the device.

Config Payload:
===============

+========+==============+=====================================================================================+
| Byte # |    Values    |                           Meaning / Purpose                                         |
+=======================+=====================================================================================+
|    0   | 0xEE         | Config Marker                                                                       |
|    1   | 0x00         | Reserved                                                                            |
|    2   | 0x00-0x0A    | Measurement mode (3 is required for temperature measurements).                      |
|    3   | 0x01 or 0x00 | Calibrate device at the end of configuration if value is 0x01 (requires 2 seconds). |
|    4   | 0x00         | Reserved                                                                            |
|    5   | 0x00         | Reserved                                                                            |
|    6   | 0x00         | Reserved                                                                            |
|    7   | 0x00         | Reserved                                                                            |
+========+==============+=====================================================================================+

### GPIO Toggle

If the temperature is above 37 degrees Celsius, then pin 4 should be set to
high, else it should be low. There should also 1 degree Ceclius of hysteresis
around this threshold to debounce the output from a noisy temperature sensor.

For example, if your initial state is low and 25 C, once you reach 38 C the pin,
should go high. To go back to low, it must reach 36 C.


### Part 2

Now that you have the temperature sensor streaming data, you can process this stream
to extract something interesting. Briefly implement some calculation on the data and
output the result in a simple manner. For instance, you could smooth the time series with a
digital filter, calculate some statistics, integrate or differentiate the signal, etc.
We leave this creative piece up to you.

The result of the operation can be logged or the data could be written to file and
plotted with a quick python script.
